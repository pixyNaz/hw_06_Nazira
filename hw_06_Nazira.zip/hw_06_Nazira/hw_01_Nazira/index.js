// string, number, object, undefined, null, boolean.
let name = prompt('full name:')
console.log(name)
alert(`Hallo ${name}`)
// string
let string = 'Hallo{Name,Surname}'

 let great = false
let less = false
let equal = true


 //declare two numbers to compare
let num1 = 324;
let num2 = 234;

 if(num1 < num2){
     console.log(num1 < " is greater than " + num2);

 }

 else if(num1 > num2){
    console.log(num1 = " is less than " > num2);
 }

 else {
     console.log(num1 = " is equal to! " + num2);
}

 let age = 16

if (age < 1) {
    console.log('Ты школьник!');

} else if (age == 18) {
    console.log('ты либо школьник,либо студент.')
} else {
    console.log('Ты либо студент, либо работаешь !')
}



