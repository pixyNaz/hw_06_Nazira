
let arr = [1232, -132, 356, 2123, 2.5, 23, 12] // 3616.5

let counter = 0
for (let i = 0; i < arr.length; i+=1) {
    counter += arr[i]
    // i +=1
    // i ++
}
console.log(counter)

let num = [98, 66, 48, 22, 86, 38 ]
let i = 0
while (i < num.length) {
    i++
    console.log(num[i] %2 === 0)
}
let people = [
    {
        name: 'Adilet',
        salary: 23000
    },
    {
        name: 'Syimyk',
        salary: 59000
    },
    {
        name: 'Meerim',
        salary: 38000
    },
    {
        name: 'Nurdin',
        salary: 15000
    }
]
console.log(people[3].level ='fhj')

for (let i = 0; i < people.length ; i++) {

    if(people[i].name !=='Nurdin'){
        console.log(people[i].salary +=1000)
    } else {
        console.log(people[i].salary+=2000)
    }
}

for (let i = 0; i < people.length; i++) {
    if(people[i].salary < 20000){
        console.log(people[i].level = 'junior')
    }else if(people[i].salary <= 50000){
        console.log(people[i].level = 'middle')
    }else {
        console.log(people[i].level = 'senior')
    }

console.log(people[i].level)
}







//[] array {} object function name(params){logic}