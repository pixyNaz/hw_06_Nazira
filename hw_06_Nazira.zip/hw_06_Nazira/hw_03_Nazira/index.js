
let firstNum = '2'
let secondNum = '4'

const equal =()=>{
    if (firstNum<secondNum){
        console.log(firstNum)
    }else if (firstNum<secondNum){
        console.log(secondNum)
    }
}
equal(firstNum, secondNum)


const countChar =(symbol, word)=> {
let num = 0

    for (let i = 0; i<word.length; i++){


        if (symbol===word[i]){
            num++
        }

    } return num
}



console.log(countChar('a', 'snaaaaaaaakes'))




let products = [
    {
        productName: 'milk',
        cost: 48
    },
    {
        productName: 'bread',
        cost: 20
    },
    {
        productName: 'egg',
        cost: 11
    },
]
const addProducts =(productName, cost )=> {
    products.push({productName : 'Suger',cost: 50}) // {product ; cost}
    // for (let i = 0; i<products.length; i++){
    //     products[i].amount += 2
    //     if (products[i].name === productName) {
    //          products[i] .amount += 2
    //     }
    // }

}

addProducts('cookies', 300)
addProducts('candies', 15)
addProducts('cookies', 300)
addProducts('cookies', 300)
console.log(products)