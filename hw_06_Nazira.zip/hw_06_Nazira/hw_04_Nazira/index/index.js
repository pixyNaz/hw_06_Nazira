let username = prompt('fullname:')
    console.log(username)
    alert(`Hallo ${username}`)
let string = 'Hallo{Name,Surname}'


let bestPeople = [
    {
        name: 'Nazira',
        salary: 34600
    },
    {
        name: 'Meerim',
        salary: 38000
    },
    {
        name: 'Firdavs',
        salary: 47263
    },
    {
        name: 'Nurdin',
        salary: 15000
    },
    {
        name: 'Temirlan',
        salary: 58456
    },
    {
        name: 'Semen',
        salary: 56654
    },
    {
        name: 'Syimyk',
        salary: 76543
    },
    {
        name: 'Luisa',
        salary: 59452
    },
    {
        name: 'Kutman',
        salary: 63213
    },
    {
        name: 'Luisa',
        salary: 59452
    },
    {
        name: 'Chyngyzhan',
        salary: 23459
    },
    {
        name: 'Aliya',
        salary: 45697
    }
]

let filtered = bestPeople.filter( (persen)=> {
    return persen.name [0]=== 'S'

})
let mapped = bestPeople.map( (person)=> {
    person.salary /= 84.5
    return person
})    
    
let reduced = bestPeople.reduce((person)=> {
    

})    

console.log(mapped)

